import pandas as pd
import numpy as np
import math

# --- ⚙️ PARAMÈTRES HYBRIDES V40 (TARGET: 2000% + HIGH SHARPE) ---
EMA_SHORT_PERIOD = 2      
EMA_LONG_PERIOD = 3       # MINIMAL
EMA_EXIT_PERIOD = 2       
EMA_ULTRA_LONG_PERIOD = 5 # RÉDUIT pour réactivité

VOLATILITY_PERIOD = 3     # Très réactif

TREND_CONFIRMATION_THRESHOLD = 0.000035  # ENCORE PLUS BAS
MOMENTUM_SLOWDOWN_THRESHOLD = 0.00001   # MINIMAL

VOLATILITY_CUTOFF = 0.085  # Légèrement augmenté

# Kelly Criterion ULTRA-AGRESSIF V41
BASE_MAX_RISK_ALLOCATION = 0.99  
KELLY_MAX_CAP = 0.97      # 97% pour 2000%
KELLY_MIN_TRADES = 2      # Immédiat

# Paramètres HYBRIDES V40
RSI_PERIOD = 4            # Un peu plus stable
RSI_OVERSOLD = 42         # Plus strict
RSI_OVERBOUGHT = 58       
MOMENTUM_BOOST_MULTIPLIER = 5.2  # x5.2 ultra-agressif
PYRAMIDING_PROFIT_THRESHOLD = 0.0055  # Pyramide à +0.55%
PYRAMIDING_MAX_MULT = 4.0  # x4.0 en pyramide

# Breakout et trend TRÈS AGRESSIFS
BREAKOUT_LOOKBACK = 3     # Réactif
BREAKOUT_BOOST = 4.2      # x4.2 sur breakout
TREND_STRENGTH_BOOST = 4.6 # x4.6 si trend fort

# --- Fonctions Utilitaires ---

def calculate_emas(prices, short_period, long_period, exit_period, ultra_long_period):
    """Calcule les Moyennes Mobiles Exponentielles (EMA)."""
    if len(prices) < ultra_long_period:
        return None, None, None, None
    series = pd.Series(prices)
    ema_short = series.ewm(span=short_period, adjust=False).mean().iloc[-1]
    ema_long = series.ewm(span=long_period, adjust=False).mean().iloc[-1]
    ema_ultra_long = series.ewm(span=ultra_long_period, adjust=False).mean().iloc[-1]
    
    if len(prices) >= exit_period:
        ema_exit = series.ewm(span=exit_period, adjust=False).mean().iloc[-1]
    else:
        ema_exit = None
        
    return ema_short, ema_long, ema_exit, ema_ultra_long

def calculate_volatility(prices, period):
    """Calcule la volatilité (écart-type des rendements)."""
    if len(prices) < period:
        return 1e-6 
    recent_prices = np.array(prices[-period:])
    returns = np.log(recent_prices[1:] / recent_prices[:-1])
    return pd.Series(returns).std()

def calculate_rsi(prices, period=5):
    """Calcule le RSI hyper-rapide."""
    if len(prices) < period + 1:
        return 50
    deltas = pd.Series(prices).diff()
    gains = deltas.where(deltas > 0, 0.0)
    losses = -deltas.where(deltas < 0, 0.0)
    avg_gain = gains.rolling(window=period).mean().iloc[-1]
    avg_loss = losses.rolling(window=period).mean().iloc[-1]
    if avg_loss == 0:
        return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def calculate_momentum_accel(prices, short, long):
    """Calcule l'accélération du momentum."""
    if len(prices) < long * 2:
        return 0
    s = pd.Series(prices)
    ema_s = s.ewm(span=short, adjust=False).mean()
    ema_l = s.ewm(span=long, adjust=False).mean()
    mom = (ema_s - ema_l) / ema_l
    if len(mom) < 5:
        return 0
    return mom.diff().iloc[-1]

def detect_breakout(prices, lookback=8):
    """Détecte si le prix actuel casse un nouveau high."""
    if len(prices) < lookback + 1:
        return False
    recent_high = max(prices[-lookback-1:-1])
    return prices[-1] > recent_high * 1.002  # +0.2% au-dessus

def calculate_trend_strength(prices, short, long):
    """Mesure la force de la tendance (0 à 1)."""
    if len(prices) < long:
        return 0
    s = pd.Series(prices)
    ema_s = s.ewm(span=short, adjust=False).mean().iloc[-1]
    ema_l = s.ewm(span=long, adjust=False).mean().iloc[-1]
    spread = abs((ema_s - ema_l) / ema_l)
    return min(spread / 0.01, 1.0)  # Normalise à 1.0 max

def calculate_kelly_f(stats):
    """Calcule le Kelly Optimal F ULTRA-AGRESSIF V41."""
    total_trades = stats['wins'] + stats['losses']
    
    if total_trades < KELLY_MIN_TRADES or stats['losses'] == 0:
        return 0.82  # START ULTRA-AGRESSIF
        
    p = stats['wins'] / total_trades
    
    avg_gain = stats['sum_gains'] / stats['wins'] if stats['wins'] > 0 else 0
    avg_loss = stats['sum_losses'] / stats['losses'] if stats['losses'] > 0 else 1e-10
    
    b = avg_gain / avg_loss if avg_loss > 0 else 2.0
    
    if b == 0:
        b = 0.01
    
    # Formule de Kelly
    f = (p * (b + 1) - 1) / b
    
    # Bonus MAXIMISÉS
    if p > 0.58:
        f *= 3.9  # x3.9
    elif p > 0.51:
        f *= 3.1
    elif p > 0.43:
        f *= 2.3
    
    if b > 1.85:
        f *= 2.9  # Ultra-agressif
    elif b > 1.45:
        f *= 2.3
    elif b > 1.05:
        f *= 1.8
    
    # Bonus série de gains
    if stats['wins'] > stats['losses'] * 1.35:
        f *= 1.9
    elif stats['wins'] > stats['losses'] * 1.15:
        f *= 1.6
    
    # Pénalité légère drawdown (Sharpe)
    if stats['losses'] > stats['wins']:
        f *= 0.94
    
    return min(max(0.82, f), KELLY_MAX_CAP)

# --- Fonction de Décision Principale (V33 Corrigée) ---

def make_decision(epoch: int, price_A: float, price_B: float):
    global history
    
    allocation_A = 0.0
    allocation_B = 0.0
    
    # Initialisation de la structure de suivi Kelly et NAV
    if epoch == 0:
        history = {
            'prices_A': [price_A], 'prices_B': [price_B],
            'allocation': {'Asset A': 0.0, 'Asset B': 0.0, 'Cash': 1.0, 'NAV': 1.0},
            'kelly_stats': {'wins': 0, 'losses': 0, 'sum_gains': 0.0, 'sum_losses': 0.0, 'last_entry_price': {'A': 0.0, 'B': 0.0}}
        }
        # Ne retourne que les clés requises
        return {'Asset A': 0.0, 'Asset B': 0.0, 'Cash': 1.0} 

    # --- 1. Calcul du PnL et Mise à Jour Kelly Stats ---
    
    last_allocation = history['allocation']
    
    # Calcul de la NAV courante
    last_nav = last_allocation.get('NAV', 1.0)
    current_nav = last_nav * (1 + last_allocation['Asset A'] * (price_A/history['prices_A'][-1] - 1) + last_allocation['Asset B'] * (price_B/history['prices_B'][-1] - 1))
    
    # Mise à jour de l'historique des prix
    history['prices_A'].append(price_A)
    history['prices_B'].append(price_B)
    prices_A = history['prices_A']
    prices_B = history['prices_B']
    
    # Variables d'entrée/sortie
    entry_A = history['kelly_stats']['last_entry_price']['A']
    entry_B = history['kelly_stats']['last_entry_price']['B']
    
    # Détermination des triggers de sortie pour la mise à jour des statistiques
    min_required_points = max(EMA_LONG_PERIOD, VOLATILITY_PERIOD, EMA_EXIT_PERIOD, EMA_ULTRA_LONG_PERIOD)
    if len(prices_A) < min_required_points:
        return {'Asset A': 0.0, 'Asset B': 0.0, 'Cash': 1.0}
    
    ema_s_A, ema_l_A, ema_exit_A, ema_ul_A = calculate_emas(prices_A, EMA_SHORT_PERIOD, EMA_LONG_PERIOD, EMA_EXIT_PERIOD, EMA_ULTRA_LONG_PERIOD)
    ema_s_B, ema_l_B, ema_exit_B, ema_ul_B = calculate_emas(prices_B, EMA_SHORT_PERIOD, EMA_LONG_PERIOD, EMA_EXIT_PERIOD, EMA_ULTRA_LONG_PERIOD)
    
    exit_A_triggered = (last_allocation['Asset A'] > 0 and (ema_exit_A < ema_s_A or price_A < ema_l_A or ema_s_A < ema_l_A))
    exit_B_triggered = (last_allocation['Asset B'] > 0 and (ema_exit_B < ema_s_B or price_B < ema_l_B or ema_s_B < ema_l_B))
    
    # Mise à jour des statistiques Kelly si sortie
    if exit_A_triggered and entry_A > 0:
        pnl = (price_A / entry_A) - 1.0
        if pnl > 0:
            history['kelly_stats']['wins'] += 1
            history['kelly_stats']['sum_gains'] += pnl
        else:
            history['kelly_stats']['losses'] += 1
            history['kelly_stats']['sum_losses'] += abs(pnl)
        history['kelly_stats']['last_entry_price']['A'] = 0.0

    if exit_B_triggered and entry_B > 0:
        pnl = (price_B / entry_B) - 1.0
        if pnl > 0:
            history['kelly_stats']['wins'] += 1
            history['kelly_stats']['sum_gains'] += pnl
        else:
            history['kelly_stats']['losses'] += 1
            history['kelly_stats']['sum_losses'] += abs(pnl)
        history['kelly_stats']['last_entry_price']['B'] = 0.0
    
    # --- 2. Calcul des Indicateurs et du Kelly Factor ---
    
    volatility_A = calculate_volatility(prices_A, VOLATILITY_PERIOD)
    MoM_A_abs = (ema_s_A - ema_l_A) / ema_l_A
    
    volatility_B = calculate_volatility(prices_B, VOLATILITY_PERIOD)
    MoM_B_abs = (ema_s_B - ema_l_B) / ema_l_B
    
    # Indicateurs supplémentaires
    rsi_A = calculate_rsi(prices_A, RSI_PERIOD)
    rsi_B = calculate_rsi(prices_B, RSI_PERIOD)
    
    accel_A = calculate_momentum_accel(prices_A, EMA_SHORT_PERIOD, EMA_LONG_PERIOD)
    accel_B = calculate_momentum_accel(prices_B, EMA_SHORT_PERIOD, EMA_LONG_PERIOD)
    
    breakout_A = detect_breakout(prices_A, BREAKOUT_LOOKBACK)
    breakout_B = detect_breakout(prices_B, BREAKOUT_LOOKBACK)
    
    trend_strength_A = calculate_trend_strength(prices_A, EMA_SHORT_PERIOD, EMA_LONG_PERIOD)
    trend_strength_B = calculate_trend_strength(prices_B, EMA_SHORT_PERIOD, EMA_LONG_PERIOD)
    
    kelly_f = calculate_kelly_f(history['kelly_stats'])
    TARGET_ALLOCATION_KELLY = min(kelly_f, BASE_MAX_RISK_ALLOCATION) 
    
    # --- 3. Logique d'Entrée et Allocation ---
    
    relative_momentum_A_vs_B = ema_l_A > ema_l_B 
    relative_momentum_B_vs_A = ema_l_B > ema_l_A
    
    avg_market_volatility = (volatility_A + volatility_B) / 2.0
    market_in_stress = avg_market_volatility > VOLATILITY_CUTOFF
    
    # Critères ULTRA-ÉLARGIS (maximum opportunités)
    A_is_leader = (
        MoM_A_abs > TREND_CONFIRMATION_THRESHOLD and 
        relative_momentum_A_vs_B and 
        (price_A > ema_ul_A or rsi_A < 57 or breakout_A)  # RSI 57
    )
    B_is_leader = (
        MoM_B_abs > TREND_CONFIRMATION_THRESHOLD and 
        relative_momentum_B_vs_A and
        (price_B > ema_ul_B or rsi_B < 57 or breakout_B)  # RSI 57
    )
    
    
    if exit_A_triggered or exit_B_triggered or market_in_stress:
        allocation_A = 0.0
        allocation_B = 0.0
        
    elif A_is_leader or B_is_leader:
        
        leader = None
        
        if A_is_leader and B_is_leader:
            score_A = MoM_A_abs + abs(accel_A) * 20 + (0.01 if breakout_A else 0) + trend_strength_A * 0.005
            score_B = MoM_B_abs + abs(accel_B) * 20 + (0.01 if breakout_B else 0) + trend_strength_B * 0.005
            leader = 'A' if score_A > score_B else 'B'
        elif A_is_leader: leader = 'A'
        elif B_is_leader: leader = 'B'

        # --- ALLOCATION HYBRIDE V40 (A) ---
        if leader == 'A':
            MAX_ALLOCATION_ADJUSTED = min(
                BASE_MAX_RISK_ALLOCATION,
                TARGET_ALLOCATION_KELLY / max(volatility_A, 0.0003)
            )
            
            # BOOST momentum MAXIMAL
            if MoM_A_abs > TREND_CONFIRMATION_THRESHOLD * 18:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 5.5)  # x5.5 !
            elif MoM_A_abs > TREND_CONFIRMATION_THRESHOLD * 9:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 3.8)
            elif MoM_A_abs > TREND_CONFIRMATION_THRESHOLD * 3:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 2.7)
            
            # BOOST accélération MAXIMAL
            if accel_A > 0.00018:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * MOMENTUM_BOOST_MULTIPLIER)  # x5.2
            elif accel_A > 0.00007:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 3.0)
            
            # BOOST RSI MAXIMAL
            if rsi_A < 57:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 3.5)  # x3.5
            elif rsi_A < RSI_OVERSOLD:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 2.6)
            
            # BOOST breakout MAXIMAL
            if breakout_A:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * BREAKOUT_BOOST)  # x4.2
            
            # BOOST trend strength MAXIMAL
            if trend_strength_A > 0.56:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * TREND_STRENGTH_BOOST)  # x4.6
            elif trend_strength_A > 0.36:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 2.0)
            
            # Pyramiding x7.5 MAXIMAL
            if entry_A > 0 and price_A > entry_A * (1 + PYRAMIDING_PROFIT_THRESHOLD):
                profit_mult = min((price_A / entry_A - 1) / PYRAMIDING_PROFIT_THRESHOLD, 7.5)  # x7.5 !
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * (1.8 + profit_mult * 0.7))
            
            # Pas de réduction - garder momentum
            # if MoM_A_abs < MOMENTUM_SLOWDOWN_THRESHOLD * 0.1 and accel_A < -0.00015:
            #     MAX_ALLOCATION_ADJUSTED *= 0.90
            
            allocation_A = MAX_ALLOCATION_ADJUSTED
            if history['kelly_stats']['last_entry_price']['A'] == 0.0:
                history['kelly_stats']['last_entry_price']['A'] = price_A

        elif leader == 'B':
            MAX_ALLOCATION_ADJUSTED = min(
                BASE_MAX_RISK_ALLOCATION,
                TARGET_ALLOCATION_KELLY / max(volatility_B, 0.0005)
            )
            
            # BOOST momentum MAXIMAL (B)
            if MoM_B_abs > TREND_CONFIRMATION_THRESHOLD * 18:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 5.5)  # x5.5 !
            elif MoM_B_abs > TREND_CONFIRMATION_THRESHOLD * 9:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 3.8)
            elif MoM_B_abs > TREND_CONFIRMATION_THRESHOLD * 3:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 2.7)
            
            # BOOST accélération MAXIMAL (B)
            if accel_B > 0.00018:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * MOMENTUM_BOOST_MULTIPLIER)  # x5.2
            elif accel_B > 0.00007:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 3.0)
            
            # BOOST RSI MAXIMAL (B)
            if rsi_B < 57:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 3.5)  # x3.5
            elif rsi_B < RSI_OVERSOLD:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 2.6)
            
            # BOOST breakout MAXIMAL (B)
            if breakout_B:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * BREAKOUT_BOOST)  # x4.2
            
            # BOOST trend strength MAXIMAL (B)
            if trend_strength_B > 0.56:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * TREND_STRENGTH_BOOST)  # x4.6
            elif trend_strength_B > 0.36:
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * 2.0)
            
            # Pyramiding x7.5 MAXIMAL (B)
            if entry_B > 0 and price_B > entry_B * (1 + PYRAMIDING_PROFIT_THRESHOLD):
                profit_mult = min((price_B / entry_B - 1) / PYRAMIDING_PROFIT_THRESHOLD, 7.5)  # x7.5 !
                MAX_ALLOCATION_ADJUSTED = min(0.99, MAX_ALLOCATION_ADJUSTED * (1.8 + profit_mult * 0.7))
            
            # Pas de réduction - garder momentum (B)
            # if MoM_B_abs < MOMENTUM_SLOWDOWN_THRESHOLD * 0.1 and accel_B < -0.00015:
            #     MAX_ALLOCATION_ADJUSTED *= 0.90
                
            allocation_B = MAX_ALLOCATION_ADJUSTED
            if history['kelly_stats']['last_entry_price']['B'] == 0.0:
                history['kelly_stats']['last_entry_price']['B'] = price_B
    
    
    # --- 4. Finalisation et Stockage de la NAV (CORRECTION) ---

    allocation_Cash = 1.0 - allocation_A - allocation_B
    allocation_Cash = max(0.0, allocation_Cash) 

    final_allocation = {
        'Asset A': allocation_A, 
        'Asset B': allocation_B, 
        'Cash': allocation_Cash,
    }

    # Stockage de la NAV et de l'allocation pour le prochain cycle DANS HISTORY
    history['allocation']['NAV'] = current_nav
    history['allocation']['Asset A'] = allocation_A
    history['allocation']['Asset B'] = allocation_B
    history['allocation']['Cash'] = allocation_Cash
    
    return final_allocation